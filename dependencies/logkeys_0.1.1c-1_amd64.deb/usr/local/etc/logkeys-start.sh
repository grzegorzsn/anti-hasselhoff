#!/bin/sh
logkeys --start
